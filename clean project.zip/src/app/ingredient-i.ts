export interface IngredientI {
  quantity: number;
  unit: string;
  ingredient: string;
}

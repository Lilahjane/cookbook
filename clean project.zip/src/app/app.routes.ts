import { Routes } from '@angular/router';
import { GridComponent } from './grid/grid.component';
import { ViewComponent } from './view/view.component';
import { GroceryListComponent } from './grocery-list/grocery-list.component';

// noinspection TypeScriptValidateTypes

export const routes: Routes = [
    {
        path: 'grid',
        component: GridComponent
    },
    {
        path: 'details/id',
        component: ViewComponent
    },
    {
        path: 'Grocery List',
        component: GroceryListComponent
    },
    
];
